package com.web.basic.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyTestController {
	
	/**
	 * ��ü ���� ������ ��ȯ
	 * @return
	 */
	@RequestMapping(value = "/api/v1/data/currency")
	public String getCurrency() {
		return readFile("");
	}
	
	/**
	 * {currency} ���ݸ� ��ȯ
	 * @param currency
	 * @return
	 */
	@RequestMapping(value = "/api/v1/data/currency/{currency}")
	public String getSelectedCurrency(@PathVariable("currency") String currency) {	
		return readFile(currency.toUpperCase()+"_KRW");
	}
	
	/**
	 * price.json �б�
	 * @param file
	 * @param currency
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String readFile(String currency){
		ClassPathResource resource = new ClassPathResource("json/price.json");
		JSONObject jsonObject = new JSONObject();
		try {		
			Path path = Paths.get(resource.getURI());
			List<String> content = Files.readAllLines(path);
			
			if(content.size() > 0) {
				JSONParser parser = new JSONParser();
				JSONArray jArray  = (JSONArray) parser.parse(content.toString());
				if(!currency.isEmpty()) {					
					Iterator it    = jArray.iterator();
					JSONObject obj = null;
					String result  = "";
					while(it.hasNext()) {
						obj = (JSONObject) it.next();
						result = obj.get(currency).toString();
					}
					
					JSONObject jsonObj = filterJson((JSONObject) parser.parse(result));
					jsonObject.put("status", "success");
					jsonObject.put("data"  , jsonObj);

				}else {					
					JSONObject object = new JSONObject();
					for(int i=0; i<jArray.size(); i++) {
						JSONObject obj = (JSONObject) jArray.get(i);
						Iterator it = obj.keySet().iterator();
						while(it.hasNext()) {
							String key = (String) it.next();
							if(key.indexOf("KRW") != -1) 
								object.put(key, filterJson((JSONObject) parser.parse(obj.get(key).toString())));
						}
					}		
					jsonObject.put("status", "success");
					jsonObject.put("data"  , object);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonObject.toString();
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject filterJson(JSONObject obj) {
		String[] exchange  = {"bithumb","coinone","korbit","bitfinex"};
		JSONParser parser  = new JSONParser();					
		JSONObject jsonObj = new JSONObject();
		for(int i=0; i<exchange.length; i++) {
			if(obj.get(exchange[i]) != null) {
				try {
					JSONObject object = (JSONObject) parser.parse(obj.get(exchange[i]).toString());
					JSONObject objVal = new JSONObject();
					objVal.put("originPair", object.get("originPair").toString());
					objVal.put("last"      , object.get("last").toString());
					jsonObj.put(exchange[i], objVal);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else {
				jsonObj.put(exchange[i], null);
			}
		}
		return jsonObj;
	}

}
