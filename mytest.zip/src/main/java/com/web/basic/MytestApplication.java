package com.web.basic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@SpringBootApplication
public class MytestApplication {
	
	private static final String PREFIX = "/WEB-INF/views/";
	private static final String SUEFIX = ".jsp";

	public static void main(String[] args) {
		SpringApplication.run(MytestApplication.class, args);
	}
	
	@Bean
	public InternalResourceViewResolver setViewResolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
			resolver.setPrefix(PREFIX);
			resolver.setSuffix(SUEFIX);
		return resolver;
	}
}
